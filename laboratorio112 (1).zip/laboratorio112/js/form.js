$(function() {
    $("form.formal fieldset").addClass("ui-widget-content");
    $("form.formal legend").addClass("ui-widget-header ui-widget-content ui-corner-all");
    
    $("form.formal input[type=text]").addClass("ui-widget ui-widget-content ui-corner-all");
    $("form.formal textarea").addClass("ui-widget ui-widget-content ui-corner-all");
    $("form.formal select").addClass("ui-widget ui-widget-content ui-corner-all");
    
    $("form.formal input[type=button]").button();
	$("form.formal input[type=button]").click(function() {
     		alert("Botón enviando mensaje");
   	});
});

